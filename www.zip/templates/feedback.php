<ion-view view-title="Feedback">
  <ion-content class="has-header">
    <!--<div class="list">
  <label class="item item-input">
    <span class="input-label">Email</span>
    <input placeholder = "john@wharton.upenn.edu" type="text">
  </label>
  <label class="item item-input item-select">
    <div class="input-label">
      Feedback Type
    </div>
    <select>
      <option>Conference</option>
      <option selected>Committees</option>
      <option>Hotel</option>
      <option>App</option>
    </select>
  </label>
  <label class="item item-input">
    <span class="input-label">Feedback</span>
    <textarea style ="vertical-align: middle;" type="text" placeholder="The conference was amazing!" rows="5" cols="10">
  </textarea>
</label>
<button style ="width: 100%;" class = "button button-positive"> Submit </button>
</div>-->
<iframe src="https://docs.google.com/forms/d/1pq0rAkfVy2IVyW472YAM989yC5ZiMvlPegttPX6bFks/viewform?embedded=true" width="100%" height="100%" frameborder="0" marginheight="0" marginwidth="0">Loading...</iframe>
  </ion-content>
</ion-view>